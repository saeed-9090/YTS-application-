package com.shortsai.app.ui

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.MediaController
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.shortsai.app.api.models.GenerationState
import com.shortsai.app.databinding.FragmentPreviewBinding
import com.shortsai.app.video.VideoExporter
import com.shortsai.app.viewmodel.GallerySaveState
import com.shortsai.app.viewmodel.VideoViewModel
import com.shortsai.app.viewmodel.VideoViewModelFactory
import java.io.File

class PreviewFragment : Fragment() {

    // ==========================================
    // VIEW BINDING
    // ==========================================

    private var _binding: FragmentPreviewBinding? = null
    private val binding get() = _binding!!

    // ==========================================
    // VIEW MODEL + HELPERS
    // ==========================================

    private val viewModel: VideoViewModel by activityViewModels {
        VideoViewModelFactory(requireContext())
    }

    private lateinit var videoExporter: VideoExporter
    private var mediaPlayer: MediaPlayer? = null
    private var isPlaying = false
    private var currentVideoPath: String = ""

    // Handler for duration updates
    private val handler = Handler(Looper.getMainLooper())
    private val updateDurationRunnable = object : Runnable {
        override fun run() {
            updateDurationBadge()
            handler.postDelayed(this, 1000)
        }
    }

    // ==========================================
    // LIFECYCLE
    // ==========================================

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPreviewBinding.inflate(
            inflater,
            container,
            false
        )
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        videoExporter = VideoExporter(requireContext())

        setupVideoPlayer()
        setupButtons()
        observeViewModel()
        loadVideoData()
    }

    override fun onPause() {
        super.onPause()
        pauseVideo()
        handler.removeCallbacks(updateDurationRunnable)
    }

    override fun onResume() {
        super.onResume()
        // Refresh video if available
        if (currentVideoPath.isNotEmpty()) {
            loadVideo(currentVideoPath)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        releasePlayer()
        handler.removeCallbacks(updateDurationRunnable)
        _binding = null
    }

    // ==========================================
    // VIDEO PLAYER SETUP
    // ==========================================

    private fun setupVideoPlayer() {
        // Setup media controller
        val mediaController = MediaController(requireContext())
        mediaController.setAnchorView(binding.videoPlayer)
        binding.videoPlayer.setMediaController(mediaController)

        // Play/pause overlay click
        binding.overlayPlay.setOnClickListener {
            togglePlayPause()
        }

        // Video prepared listener
        binding.videoPlayer.setOnPreparedListener { mp ->
            mediaPlayer = mp
            mp.isLooping = true

            // Auto play
            playVideo()

            // Start duration updates
            handler.post(updateDurationRunnable)

            Toast.makeText(
                requireContext(),
                "✅ Video ready to play!",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Video error listener
        binding.videoPlayer.setOnErrorListener { _, what, extra ->
            Toast.makeText(
                requireContext(),
                "Video error: $what/$extra",
                Toast.LENGTH_SHORT
            ).show()
            false
        }
    }

    // ==========================================
    // LOAD VIDEO
    // ==========================================

    private fun loadVideo(videoPath: String) {
        try {
            val videoFile = File(videoPath)

            if (!videoFile.exists()) {
                Toast.makeText(
                    requireContext(),
                    "Video file not found",
                    Toast.LENGTH_SHORT
                ).show()
                return
            }

            currentVideoPath = videoPath
            val uri = Uri.fromFile(videoFile)
            binding.videoPlayer.setVideoURI(uri)
            binding.videoPlayer.requestFocus()

        } catch (e: Exception) {
            Toast.makeText(
                requireContext(),
                "Cannot load video: ${e.message}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // ==========================================
    // PLAYBACK CONTROLS
    // ==========================================

    private fun togglePlayPause() {
        if (isPlaying) {
            pauseVideo()
        } else {
            playVideo()
        }
    }

    private fun playVideo() {
        try {
            binding.videoPlayer.start()
            isPlaying = true
            binding.overlayPlay.animate()
                .alpha(0f)
                .setDuration(300)
                .start()
        } catch (e: Exception) {
            // Video not ready yet
        }
    }

    private fun pauseVideo() {
        try {
            if (binding.videoPlayer.isPlaying) {
                binding.videoPlayer.pause()
            }
            isPlaying = false
            binding.overlayPlay.animate()
                .alpha(1f)
                .setDuration(300)
                .start()
            binding.ivPlayBtn.setImageResource(
                android.R.drawable.ic_media_play
            )
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun releasePlayer() {
        try {
            binding.videoPlayer.stopPlayback()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            // Ignore
        }
    }

    // ==========================================
    // DURATION BADGE UPDATE
    // ==========================================

    private fun updateDurationBadge() {
        try {
            if (binding.videoPlayer.isPlaying) {
                val currentMs = binding.videoPlayer.currentPosition
                val totalMs = binding.videoPlayer.duration
                val current = currentMs / 1000
                val total = totalMs / 1000
                binding.tvDurationBadge.text =
                    "${formatTime(current)} / ${formatTime(total)}"
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun formatTime(seconds: Int): String {
        val mins = seconds / 60
        val secs = seconds % 60
        return String.format("%d:%02d", mins, secs)
    }

    // ==========================================
    // BUTTONS SETUP
    // ==========================================

    private fun setupButtons() {

        // Save to gallery
        binding.btnSave.setOnClickListener {
            viewModel.saveVideoToGallery()
        }

        // Share video
        binding.btnShare.setOnClickListener {
            if (currentVideoPath.isNotEmpty()) {
                videoExporter.shareVideo(currentVideoPath)
            } else {
                Toast.makeText(
                    requireContext(),
                    "No video to share",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // New video
        binding.btnNewVideo.setOnClickListener {
            // Reset state and go back home
            viewModel.resetState()
            viewModel.cleanupTempFiles()
            findNavController().navigate(
                R.id.action_preview_to_home
            )
        }

        // Show full script toggle
        binding.tvShowFullScript.setOnClickListener {
            val scriptView = binding.tvScriptPreview
            val isExpanded = scriptView.maxLines == Int.MAX_VALUE

            if (isExpanded) {
                scriptView.maxLines = 6
                binding.tvShowFullScript.text = "Show full script ▼"
            } else {
                scriptView.maxLines = Int.MAX_VALUE
                binding.tvShowFullScript.text = "Show less ▲"
            }
        }
    }

    // ==========================================
    // OBSERVE VIEW MODEL
    // ==========================================

    private fun observeViewModel() {

        // Gallery save state
        viewModel.gallerySaveState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is GallerySaveState.Saving -> {
                    binding.btnSave.isEnabled = false
                    binding.btnSave.text = "💾 Saving..."
                }
                is GallerySaveState.Success -> {
                    binding.btnSave.isEnabled = true
                    binding.btnSave.text = "✅ Saved!"
                    Toast.makeText(
                        requireContext(),
                        "✅ Video saved to Gallery!",
                        Toast.LENGTH_LONG
                    ).show()
                }
                is GallerySaveState.Error -> {
                    binding.btnSave.isEnabled = true
                    binding.btnSave.text = "💾 Save to Gallery"
                    Toast.makeText(
                        requireContext(),
                        "❌ Save failed: ${state.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        // Toast messages
        viewModel.toastMessage.observe(viewLifecycleOwner) { msg ->
            if (msg.isNotEmpty()) {
                Toast.makeText(
                    requireContext(),
                    msg,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // ==========================================
    // LOAD VIDEO DATA
    // ==========================================

    private fun loadVideoData() {

        // Get video path from ViewModel
        val videoPath = viewModel.videoPath.value ?: ""
        val script = viewModel.videoScript.value

        if (videoPath.isEmpty()) {
            Toast.makeText(
                requireContext(),
                "No video generated yet",
                Toast.LENGTH_SHORT
            ).show()
            findNavController().navigateUp()
            return
        }

        // Load video
        loadVideo(videoPath)

        // Load script data
        script?.let { vs ->

            // Title
            binding.tvVideoTitle.text = vs.title.ifEmpty {
                "My AI Short"
            }

            // Hashtags
            binding.tvHashtags.text = vs.hashtags
                .joinToString(" ")
                .ifEmpty { "#shorts #ai #viral" }

            // Script preview
            val fullScript = vs.script.ifEmpty {
                vs.scenes.joinToString(" ") { it.narration }
            }
            binding.tvScriptPreview.text = fullScript

            // Show full script toggle
            if (fullScript.length > 150) {
                binding.tvShowFullScript.visibility = View.VISIBLE
            }

            // Scene count
            binding.tvScenes.text = vs.scenes.size.toString()
        }

        // Load video info
        loadVideoFileInfo(videoPath)
    }

    // ==========================================
    // LOAD VIDEO FILE INFO
    // ==========================================

    private fun loadVideoFileInfo(videoPath: String) {
        try {
            val file = File(videoPath)
            if (file.exists()) {
                // File size
                val sizeMB = file.length() / (1024.0 * 1024.0)
                binding.tvFileSize.text = String.format("%.1fMB", sizeMB)
            }

            // Duration from MediaPlayer
            binding.videoPlayer.setOnPreparedListener { mp ->
                val totalMs = mp.duration
                val totalSecs = totalMs / 1000
                binding.tvDuration.text = "${totalSecs}s"
                binding.tvDurationBadge.text = "0:00 / ${formatTime(totalSecs)}"

                // Auto play
                mp.isLooping = true
                playVideo()
                handler.post(updateDurationRunnable)
            }

        } catch (e: Exception) {
            // Ignore info load error
        }
    }
}