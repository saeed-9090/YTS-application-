package com.shortsai.app.repository

import android.content.Context
import android.util.Log
import com.shortsai.app.api.ApiClient
import com.shortsai.app.api.ApiManager
import com.shortsai.app.api.models.*
import com.shortsai.app.utils.Constants
import com.shortsai.app.utils.FileUtils
import com.shortsai.app.utils.SharedPrefsManager
import com.shortsai.app.video.FFmpegProcessor
import com.shortsai.app.video.VideoBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

class VideoRepository(private val context: Context) {

    private val TAG = "VideoRepository"

    // ==========================================
    // DEPENDENCIES
    // ==========================================

    private val prefs = SharedPrefsManager(context)
    private val apiManager = ApiManager(context)
    private val ffmpegProcessor = FFmpegProcessor(context)
    private val videoBuilder = VideoBuilder(context, ffmpegProcessor)

    // ==========================================
    // INIT API CLIENT
    // ==========================================

    init {
        ApiClient.initialize(context)
        Log.d(TAG, "VideoRepository initialized")
    }

    // ==========================================
    // MAIN: FULL VIDEO GENERATION PIPELINE
    // ==========================================

    /**
     * Complete pipeline:
     * Topic → Script → Images → Audio → Video
     * Emits GenerationState updates via Flow
     */
    fun generateCompleteVideo(topic: String): Flow<GenerationState> = flow {

        Log.d(TAG, "========================================")
        Log.d(TAG, "Starting full pipeline for: $topic")
        Log.d(TAG, "========================================")

        // Save topic to prefs
        prefs.saveLastTopic(topic)

        // Track all data
        var videoScript: VideoScript? = null
        var imagePaths: List<String> = emptyList()
        var audioPath: String = ""

        // ==============================
        // PHASE 1: API CALLS
        // ==============================

        // Collect API generation states
        apiManager.generateVideoContent(topic).collect { state ->
            when (state) {
                is GenerationState.Loading -> {
                    // Forward loading states
                    emit(state)
                }

                is GenerationState.Success -> {
                    // API phase complete
                    videoScript = state.videoScript
                    audioPath = state.videoPath // Currently holds audio path

                    // Extract image paths from scenes
                    imagePaths = state.videoScript.scenes
                        .filter { it.imagePath.isNotEmpty() }
                        .map { it.imagePath }

                    Log.d(TAG, "API phase complete")
                    Log.d(TAG, "Script: ${videoScript?.title}")
                    Log.d(TAG, "Images: ${imagePaths.size}")
                    Log.d(TAG, "Audio: $audioPath")
                }

                is GenerationState.Error -> {
                    // Forward errors
                    emit(state)
                    return@collect
                }

                is GenerationState.Idle -> { /* ignore */ }
            }
        }

        // Validate we have all required data
        if (videoScript == null) {
            emit(GenerationState.Error("Script generation failed"))
            return@flow
        }

        if (imagePaths.isEmpty()) {
            emit(GenerationState.Error("No images were generated"))
            return@flow
        }

        if (audioPath.isEmpty()) {
            emit(GenerationState.Error("Audio generation failed"))
            return@flow
        }

        // ==============================
        // PHASE 2: VIDEO BUILDING
        // ==============================

        emit(GenerationState.Loading(
            progress = Constants.Progress.STEP_VIDEO_BUILD,
            message = Constants.Progress.MSG_VIDEO
        ))

        Log.d(TAG, "=== PHASE 2: Video Building ===")

        val outputVideoPath = buildVideo(
            script = videoScript!!,
            imagePaths = imagePaths,
            audioPath = audioPath,
            onProgress = { progress, message ->
                // We can't emit from here directly
                // Progress is handled by FFmpeg callbacks
                Log.d(TAG, "Video build: $progress% - $message")
            }
        )

        if (outputVideoPath == null) {
            emit(GenerationState.Error(Constants.Errors.FFMPEG_ERROR))
            return@flow
        }

        // ==============================
        // PHASE 3: FINALIZE
        // ==============================

        emit(GenerationState.Loading(
            progress = 95,
            message = Constants.Progress.MSG_SAVING
        ))

        // Increment video count
        prefs.incrementVideoCount()

        Log.d(TAG, "========================================")
        Log.d(TAG, "Pipeline COMPLETE!")
        Log.d(TAG, "Output: $outputVideoPath")
        Log.d(TAG, "========================================")

        // Final success
        emit(GenerationState.Success(
            videoPath = outputVideoPath,
            videoScript = videoScript!!
        ))

    }.flowOn(Dispatchers.IO)

    // ==========================================
    // VIDEO BUILDING
    // ==========================================

    /**
     * Build final video using FFmpeg
     */
    private suspend fun buildVideo(
        script: VideoScript,
        imagePaths: List<String>,
        audioPath: String,
        onProgress: (Int, String) -> Unit
    ): String? {

        return try {
            val outputFile = File(
                FileUtils.getOutputDir(context),
                FileUtils.generateVideoFileName()
            )

            Log.d(TAG, "Building video to: ${outputFile.absolutePath}")
            Log.d(TAG, "Image count: ${imagePaths.size}")
            Log.d(TAG, "Audio: $audioPath")

            val success = videoBuilder.buildVideo(
                imagePaths = imagePaths,
                audioPath = audioPath,
                outputPath = outputFile.absolutePath,
                scenes = script.scenes,
                onProgress = onProgress
            )

            if (success && FileUtils.isValidFile(outputFile)) {
                val sizeMB = FileUtils.getFileSizeMB(outputFile)
                Log.d(TAG, "Video created: ${sizeMB}MB")
                outputFile.absolutePath
            } else {
                Log.e(TAG, "Video file not created or empty")
                null
            }

        } catch (e: Exception) {
            Log.e(TAG, "Video build exception: ${e.message}")
            null
        }
    }

    // ==========================================
    // SAVE VIDEO TO GALLERY
    // ==========================================

    /**
     * Save generated video to device gallery
     */
    suspend fun saveVideoToGallery(videoPath: String): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val videoFile = File(videoPath)

                if (!FileUtils.isValidFile(videoFile)) {
                    return@withContext Result.failure(
                        Exception("Video file not found")
                    )
                }

                val uri = FileUtils.saveVideoToGallery(context, videoFile)

                if (uri != null) {
                    Log.d(TAG, "Video saved to gallery: $uri")
                    Result.success("Video saved successfully!")
                } else {
                    Result.failure(Exception("Failed to save to gallery"))
                }

            } catch (e: Exception) {
                Log.e(TAG, "Gallery save failed: ${e.message}")
                Result.failure(e)
            }
        }
    }

    // ==========================================
    // CLEANUP
    // ==========================================

    /**
     * Clean temp files after video is saved
     */
    suspend fun cleanupTempFiles() {
        withContext(Dispatchers.IO) {
            FileUtils.cleanupTempFiles(context)
            Log.d(TAG, "Temp files cleaned")
        }
    }

    // ==========================================
    // PREFS ACCESS
    // ==========================================

    fun getApiKey() = prefs.getApiKey()

    fun saveApiKey(key: String) {
        prefs.saveApiKey(key)
        ApiClient.updateApiKey(key)
    }

    fun hasValidApiKey() = prefs.hasApiKey()

    fun getVideoCount() = prefs.getVideoCount()

    fun getLastTopic() = prefs.getLastTopic()

    // ==========================================
    // VALIDATION
    // ==========================================

    /**
     * Validate topic input
     */
    fun validateTopic(topic: String): ValidationResult {
        return when {
            topic.isBlank() ->
                ValidationResult.Error("Please enter a topic")

            topic.length < 3 ->
                ValidationResult.Error("Topic too short (min 3 chars)")

            topic.length > 200 ->
                ValidationResult.Error("Topic too long (max 200 chars)")

            !prefs.hasApiKey() ->
                ValidationResult.Error("Please set your OpenAI API key in settings")

            else -> ValidationResult.Success
        }
    }
}

// ==========================================
// VALIDATION RESULT
// ==========================================

sealed class ValidationResult {
    object Success : ValidationResult()
    data class Error(val message: String) : ValidationResult()
}