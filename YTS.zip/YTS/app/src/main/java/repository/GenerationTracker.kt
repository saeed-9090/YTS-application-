package com.shortsai.app.repository

import android.util.Log

/**
 * Tracks generation pipeline progress
 * Provides detailed step-by-step logging
 */
class GenerationTracker {

    private val TAG = "GenerationTracker"

    // ==========================================
    // TRACKING STATE
    // ==========================================

    private var startTime: Long = 0L
    private val stepTimings = mutableMapOf<String, Long>()
    private var currentStep = ""

    // ==========================================
    // STEP TRACKING
    // ==========================================

    fun startTracking() {
        startTime = System.currentTimeMillis()
        Log.d(TAG, "⏱️ Generation started")
    }

    fun startStep(stepName: String) {
        currentStep = stepName
        stepTimings[stepName] = System.currentTimeMillis()
        Log.d(TAG, "▶️ Step started: $stepName")
    }

    fun endStep(stepName: String, success: Boolean = true) {
        val startTime = stepTimings[stepName] ?: return
        val duration = System.currentTimeMillis() - startTime
        val status = if (success) "✅" else "❌"
        Log.d(TAG, "$status Step done: $stepName (${duration}ms)")
    }

    fun complete() {
        val total = System.currentTimeMillis() - startTime
        Log.d(TAG, "🎉 Generation complete in ${total}ms")
        printSummary(total)
    }

    fun failed(reason: String) {
        val total = System.currentTimeMillis() - startTime
        Log.e(TAG, "💥 Generation failed after ${total}ms: $reason")
    }

    // ==========================================
    // SUMMARY
    // ==========================================

    private fun printSummary(totalMs: Long) {
        Log.d(TAG, "=== GENERATION SUMMARY ===")
        stepTimings.forEach { (step, _) ->
            Log.d(TAG, "  $step: completed")
        }
        Log.d(TAG, "  Total time: ${totalMs / 1000}s")
        Log.d(TAG, "==========================")
    }

    // ==========================================
    // PROGRESS CALCULATOR
    // ==========================================

    /**
     * Calculate image generation progress
     */
    fun calculateImageProgress(
        current: Int,
        total: Int,
        startPercent: Int = 20,
        endPercent: Int = 60
    ): Int {
        val range = endPercent - startPercent
        val stepProgress = (current.toFloat() / total.toFloat()) * range
        return startPercent + stepProgress.toInt()
    }

    /**
     * Get estimated time remaining
     */
    fun getEstimatedTimeRemaining(
        currentProgress: Int,
        totalProgress: Int = 100
    ): String {
        if (currentProgress <= 0) return "Calculating..."

        val elapsed = System.currentTimeMillis() - startTime
        val totalEstimated = (elapsed * totalProgress) / currentProgress
        val remaining = totalEstimated - elapsed

        return when {
            remaining < 10000 -> "Almost done..."
            remaining < 30000 -> "~${remaining / 1000}s remaining"
            remaining < 60000 -> "~${remaining / 1000}s remaining"
            else -> "~${remaining / 60000}min remaining"
        }
    }
}