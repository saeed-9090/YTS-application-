package com.shortsai.app.repository

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.shortsai.app.api.models.VideoScript
import java.io.File

/**
 * Simple cache for generated scripts
 * Avoids re-generating same topic
 */
class VideoCache(private val context: Context) {

    private val TAG = "VideoCache"
    private val gson = Gson()
    private val cacheDir = File(context.cacheDir, "scripts")

    init {
        if (!cacheDir.exists()) cacheDir.mkdirs()
    }

    // ==========================================
    // CACHE OPERATIONS
    // ==========================================

    /**
     * Save script to cache
     */
    fun cacheScript(topic: String, script: VideoScript) {
        try {
            val key = generateKey(topic)
            val file = File(cacheDir, "$key.json")
            file.writeText(gson.toJson(script))
            Log.d(TAG, "Script cached for: $topic")
        } catch (e: Exception) {
            Log.e(TAG, "Cache write failed: ${e.message}")
        }
    }

    /**
     * Get cached script if exists
     */
    fun getCachedScript(topic: String): VideoScript? {
        return try {
            val key = generateKey(topic)
            val file = File(cacheDir, "$key.json")

            if (file.exists() && isNotExpired(file)) {
                val json = file.readText()
                val script = gson.fromJson(json, VideoScript::class.java)
                Log.d(TAG, "Cache HIT for: $topic")
                script
            } else {
                Log.d(TAG, "Cache MISS for: $topic")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cache read failed: ${e.message}")
            null
        }
    }

    /**
     * Check if cache is still valid (24 hours)
     */
    private fun isNotExpired(file: File): Boolean {
        val ageMs = System.currentTimeMillis() - file.lastModified()
        val maxAgeMs = 24 * 60 * 60 * 1000L // 24 hours
        return ageMs < maxAgeMs
    }

    /**
     * Generate cache key from topic
     */
    private fun generateKey(topic: String): String {
        return topic.lowercase()
            .replace(" ", "_")
            .replace(Regex("[^a-z0-9_]"), "")
            .take(50)
    }

    /**
     * Clear all cached scripts
     */
    fun clearCache() {
        cacheDir.listFiles()?.forEach { it.delete() }
        Log.d(TAG, "Cache cleared")
    }

    /**
     * Get cache size in KB
     */
    fun getCacheSizeKB(): Long {
        return (cacheDir.listFiles()
            ?.sumOf { it.length() } ?: 0L) / 1024
    }
}