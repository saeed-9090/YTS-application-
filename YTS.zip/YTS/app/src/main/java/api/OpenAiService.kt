package com.shortsai.app.api

import com.shortsai.app.api.models.ChatRequest
import com.shortsai.app.api.models.ChatResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface OpenAIService {

    /**
     * Chat Completion endpoint
     * Used for script generation
     */
    @POST("chat/completions")
    suspend fun generateScript(
        @Body request: ChatRequest
    ): Response<ChatResponse>
}