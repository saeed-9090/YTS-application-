package com.shortsai.app.api

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.shortsai.app.api.models.*
import com.shortsai.app.utils.Constants
import com.shortsai.app.utils.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

class AudioApiHandler(
    private val ttsService: TTSService,
    private val context: Context
) {

    private val TAG = "AudioApiHandler"

    // ==========================================
    // GENERATE VOICEOVER VIA OPENAI TTS
    // ==========================================

    /**
     * Generate voiceover using OpenAI TTS API
     * Returns path to audio file
     */
    suspend fun generateVoiceover(
        script: String,
        onProgress: ((String) -> Unit)? = null
    ): StepResult<String> {

        return try {
            onProgress?.invoke("🎤 Generating voiceover...")
            Log.d(TAG, "Generating TTS for script (${script.length} chars)")

            // OpenAI TTS has 4096 char limit
            val truncatedScript = if (script.length > 4000) {
                script.substring(0, 4000)
            } else {
                script
            }

            // Build TTS request
            val request = TTSRequest(
                model = Constants.TTS_MODEL,
                input = truncatedScript,
                voice = Constants.TTS_VOICE,
                responseFormat = "mp3",
                speed = 1.1       // Slightly faster for Shorts
            )

            // Make API call
            val response = ttsService.generateSpeech(request)

            if (response.isSuccessful) {
                val responseBody = response.body()
                    ?: return StepResult.Error("Empty audio response")

                // Save audio bytes to file
                val audioPath = withContext(Dispatchers.IO) {
                    val audioDir = FileUtils.getAudioDir(context)
                    val audioFile = File(
                        audioDir,
                        FileUtils.generateAudioFileName()
                    )

                    val audioBytes = responseBody.bytes()
                    val saved = FileUtils.saveAudioToFile(audioBytes, audioFile)

                    if (saved && FileUtils.isValidFile(audioFile)) {
                        audioFile.absolutePath
                    } else {
                        null
                    }
                }

                if (audioPath != null) {
                    Log.d(TAG, "Voiceover saved: $audioPath")
                    StepResult.Success(audioPath)
                } else {
                    // Fallback to Android TTS
                    Log.w(TAG, "OpenAI TTS failed, using Android TTS")
                    generateVoiceoverFallback(script)
                }

            } else {
                val code = response.code()
                Log.e(TAG, "TTS API error: $code")

                // Fallback to Android TTS on API error
                Log.w(TAG, "Falling back to Android TTS")
                generateVoiceoverFallback(script)
            }

        } catch (e: Exception) {
            Log.e(TAG, "TTS exception: ${e.message}")

            // Always fallback to Android TTS
            Log.w(TAG, "Exception, using Android TTS fallback")
            generateVoiceoverFallback(script)
        }
    }

    // ==========================================
    // ANDROID TTS FALLBACK
    // ==========================================

    /**
     * Fallback: Use Android built-in TTS
     * Works without internet/API
     */
    private suspend fun generateVoiceoverFallback(
        script: String
    ): StepResult<String> {

        return withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { continuation ->

                var tts: TextToSpeech? = null

                tts = TextToSpeech(context) { status ->
                    if (status == TextToSpeech.SUCCESS) {

                        tts?.language = Locale.US
                        tts?.setPitch(1.0f)
                        tts?.setSpeechRate(1.1f)

                        val audioDir = FileUtils.getAudioDir(context)
                        val audioFile = File(
                            audioDir,
                            FileUtils.generateAudioFileName()
                        )

                        // Save to file using Android TTS
                        val params = android.os.Bundle()
                        params.putString(
                            TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID,
                            "voiceover"
                        )

                        @Suppress("DEPRECATION")
                        val result = tts?.synthesizeToFile(
                            script,
                            params,
                            audioFile,
                            "voiceover"
                        )

                        tts?.setOnUtteranceProgressListener(
                            object : android.speech.tts.UtteranceProgressListener() {

                                override fun onStart(utteranceId: String?) {
                                    Log.d(TAG, "TTS synthesis started")
                                }

                                override fun onDone(utteranceId: String?) {
                                    tts?.shutdown()
                                    if (FileUtils.isValidFile(audioFile)) {
                                        Log.d(
                                            TAG,
                                            "Android TTS saved: ${audioFile.absolutePath}"
                                        )
                                        if (continuation.isActive) {
                                            continuation.resume(
                                                StepResult.Success(
                                                    audioFile.absolutePath
                                                )
                                            )
                                        }
                                    } else {
                                        if (continuation.isActive) {
                                            continuation.resume(
                                                StepResult.Error(
                                                    "Android TTS file not created"
                                                )
                                            )
                                        }
                                    }
                                }

                                @Deprecated("Deprecated in Java")
                                override fun onError(utteranceId: String?) {
                                    tts?.shutdown()
                                    Log.e(TAG, "Android TTS error")
                                    if (continuation.isActive) {
                                        continuation.resume(
                                            StepResult.Error(
                                                "Android TTS synthesis failed"
                                            )
                                        )
                                    }
                                }
                            }
                        )

                    } else {
                        Log.e(TAG, "TTS initialization failed")
                        if (continuation.isActive) {
                            continuation.resume(
                                StepResult.Error(
                                    "Android TTS not available on this device"
                                )
                            )
                        }
                    }
                }

                // Cancel TTS if coroutine cancelled
                continuation.invokeOnCancellation {
                    tts?.shutdown()
                }
            }
        }
    }

    // ==========================================
    // GET AUDIO DURATION
    // ==========================================

    /**
     * Get duration of audio file in milliseconds
     */
    suspend fun getAudioDuration(audioPath: String): Long {
        return withContext(Dispatchers.IO) {
            try {
                val retriever = android.media.MediaMetadataRetriever()
                retriever.setDataSource(audioPath)
                val duration = retriever.extractMetadata(
                    android.media.MediaMetadataRetriever
                        .METADATA_KEY_DURATION
                )?.toLong() ?: 0L
                retriever.release()
                Log.d(TAG, "Audio duration: ${duration}ms")
                duration
            } catch (e: Exception) {
                Log.e(TAG, "Duration check failed: ${e.message}")
                30000L // Default 30 seconds
            }
        }
    }

    // ==========================================
    // COMBINE SCENE NARRATIONS
    // ==========================================

    /**
     * Build full script from scene narrations
     */
    fun buildFullScript(scenes: List<SceneData>): String {
        return scenes.joinToString(
            separator = " ... "
        ) { scene ->
            scene.narration.trim()
        }
    }

    /**
     * Build script with hook
     */
    fun buildFullScriptWithHook(
        hook: String,
        scenes: List<SceneData>,
        callToAction: String
    ): String {
        val sceneText = scenes.joinToString(
            separator = " "
        ) { it.narration.trim() }

        return buildString {
            if (hook.isNotEmpty()) {
                append(hook)
                append(" ")
            }
            append(sceneText)
            if (callToAction.isNotEmpty()) {
                append(" ")
                append(callToAction)
            }
        }
    }
}