package com.shortsai.app.api

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.shortsai.app.api.models.*
import com.shortsai.app.utils.Constants

class ScriptApiHandler(
    private val openAIService: OpenAIService
) {

    private val TAG = "ScriptApiHandler"
    private val gson = Gson()

    // ==========================================
    // GENERATE SCRIPT
    // ==========================================

    /**
     * Generate complete video script from topic
     * Returns VideoScript or throws exception
     */
    suspend fun generateVideoScript(topic: String): StepResult<VideoScript> {
        return try {
            Log.d(TAG, "Generating script for topic: $topic")

            // Build request
            val request = ChatRequest(
                model = Constants.GPT_MODEL,
                messages = listOf(
                    ChatMessage(
                        role = "system",
                        content = buildSystemPrompt()
                    ),
                    ChatMessage(
                        role = "user",
                        content = Constants.getScriptPrompt(topic)
                    )
                ),
                maxTokens = 2000,
                temperature = 0.8,
                responseFormat = ResponseFormat(type = "json_object")
            )

            // Make API call
            val response = openAIService.generateScript(request)

            // Handle response
            if (response.isSuccessful) {
                val chatResponse = response.body()

                // Check for API error in body
                if (chatResponse?.error != null) {
                    return StepResult.Error(
                        "API Error: ${chatResponse.error.message}",
                        Exception(chatResponse.error.type)
                    )
                }

                // Extract content
                val content = chatResponse
                    ?.choices
                    ?.firstOrNull()
                    ?.message
                    ?.content
                    ?: return StepResult.Error("Empty response from API")

                Log.d(TAG, "Raw script response: $content")

                // Parse JSON to VideoScript
                val videoScript = parseScriptJson(content)
                    ?: return StepResult.Error("Failed to parse script JSON")

                // Validate script
                if (videoScript.scenes.isEmpty()) {
                    return StepResult.Error("No scenes generated")
                }

                Log.d(TAG, "Script generated: ${videoScript.title}")
                Log.d(TAG, "Scenes count: ${videoScript.scenes.size}")

                StepResult.Success(videoScript)

            } else {
                // Handle HTTP errors
                val errorBody = response.errorBody()?.string()
                val errorMsg = parseErrorMessage(errorBody, response.code())
                Log.e(TAG, "API Error ${response.code()}: $errorMsg")
                StepResult.Error(errorMsg)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Script generation failed: ${e.message}")
            StepResult.Error(
                getReadableError(e),
                e
            )
        }
    }

    // ==========================================
    // PARSE SCRIPT JSON
    // ==========================================

    private fun parseScriptJson(jsonContent: String): VideoScript? {
        return try {
            // Clean up JSON if needed
            val cleanJson = jsonContent
                .trim()
                .removePrefix("```json")
                .removeSuffix("```")
                .trim()

            gson.fromJson(cleanJson, VideoScript::class.java)

        } catch (e: JsonSyntaxException) {
            Log.e(TAG, "JSON parse error: ${e.message}")
            Log.e(TAG, "Raw JSON: $jsonContent")

            // Try to extract partial data
            tryExtractPartialScript(jsonContent)
        }
    }

    /**
     * Fallback parser if JSON is malformed
     */
    private fun tryExtractPartialScript(content: String): VideoScript? {
        return try {
            // Find JSON boundaries
            val startIndex = content.indexOf('{')
            val endIndex = content.lastIndexOf('}')

            if (startIndex == -1 || endIndex == -1) return null

            val jsonStr = content.substring(startIndex, endIndex + 1)
            gson.fromJson(jsonStr, VideoScript::class.java)

        } catch (e: Exception) {
            Log.e(TAG, "Partial parse also failed: ${e.message}")
            null
        }
    }

    // ==========================================
    // SYSTEM PROMPT
    // ==========================================

    private fun buildSystemPrompt(): String {
        return """
            You are an expert YouTube Shorts content creator and scriptwriter.
            You specialize in creating viral, engaging short-form video content.
            
            Key principles:
            - Always hook viewers in the first 3 seconds
            - Use simple, conversational language
            - Create visual scenes that are easy to illustrate
            - Make content that triggers emotions (surprise, curiosity, inspiration)
            - Always return valid JSON format only
            - No markdown, no extra text outside JSON
        """.trimIndent()
    }

    // ==========================================
    // ERROR HANDLING
    // ==========================================

    private fun parseErrorMessage(errorBody: String?, code: Int): String {
        return when (code) {
            401 -> Constants.Errors.API_KEY_ERROR
            429 -> Constants.Errors.QUOTA_ERROR
            408 -> Constants.Errors.TIMEOUT_ERROR
            else -> {
                try {
                    val errorResponse = gson.fromJson(
                        errorBody,
                        ChatResponse::class.java
                    )
                    errorResponse.error?.message
                        ?: Constants.Errors.UNKNOWN_ERROR
                } catch (e: Exception) {
                    "HTTP Error $code: ${Constants.Errors.UNKNOWN_ERROR}"
                }
            }
        }
    }

    private fun getReadableError(e: Exception): String {
        return when {
            e.message?.contains("timeout", ignoreCase = true) == true ->
                Constants.Errors.TIMEOUT_ERROR
            e.message?.contains("network", ignoreCase = true) == true ->
                Constants.Errors.NETWORK_ERROR
            e.message?.contains("Unable to resolve host") == true ->
                Constants.Errors.NETWORK_ERROR
            else -> Constants.Errors.UNKNOWN_ERROR
        }
    }
}