package com.shortsai.app

import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.shortsai.app.databinding.ActivityMainBinding
import com.shortsai.app.utils.PermissionUtils
import com.shortsai.app.utils.SharedPrefsManager

class MainActivity : AppCompatActivity() {

    // ==========================================
    // VIEW BINDING
    // ==========================================

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var prefs: SharedPrefsManager

    // ==========================================
    // LIFECYCLE
    // ==========================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Init prefs
        prefs = SharedPrefsManager(this)

        // Setup navigation
        setupNavigation()

        // Setup toolbar
        setupToolbar()

        // Request permissions
        requestPermissions()

        // Check API key on first launch
        checkApiKeyOnFirstLaunch()
    }

    // ==========================================
    // NAVIGATION SETUP
    // ==========================================

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment)
                as NavHostFragment

        navController = navHostFragment.navController

        // Listen for destination changes
        navController.addOnDestinationChangedListener {
                _, destination, _ ->
            handleDestinationChange(destination.id)
        }
    }

    // ==========================================
    // TOOLBAR SETUP
    // ==========================================

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // Settings button click
        binding.btnSettings.setOnClickListener {
            if (navController.currentDestination?.id
                != R.id.settingsFragment) {
                navController.navigate(
                    R.id.action_home_to_settings
                )
            }
        }
    }

    // ==========================================
    // DESTINATION CHANGE HANDLER
    // ==========================================

    private fun handleDestinationChange(destinationId: Int) {
        when (destinationId) {
            R.id.homeFragment -> {
                // Show settings button on home
                binding.btnSettings.visibility = View.VISIBLE
                supportActionBar?.setDisplayHomeAsUpEnabled(false)
            }
            R.id.previewFragment -> {
                // Show back button on preview
                binding.btnSettings.visibility = View.GONE
                supportActionBar?.setDisplayHomeAsUpEnabled(true)
            }
            R.id.settingsFragment -> {
                // Show back on settings
                binding.btnSettings.visibility = View.GONE
                supportActionBar?.setDisplayHomeAsUpEnabled(true)
            }
        }
    }

    // ==========================================
    // PERMISSIONS
    // ==========================================

    private fun requestPermissions() {
        if (!PermissionUtils.hasStoragePermissions(this)) {
            PermissionUtils.requestStoragePermissions(this)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        when (requestCode) {
            PermissionUtils.REQUEST_STORAGE_PERMISSION -> {
                if (PermissionUtils.processPermissionResult(grantResults)) {
                    Toast.makeText(
                        this,
                        "✅ Storage permission granted",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        this,
                        "⚠️ Storage permission denied. " +
                                "Videos may not save to gallery.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    // ==========================================
    // FIRST LAUNCH CHECK
    // ==========================================

    private fun checkApiKeyOnFirstLaunch() {
        if (!prefs.hasApiKey()) {
            // Show API key prompt after short delay
            binding.root.postDelayed({
                Toast.makeText(
                    this,
                    "⚠️ Please add your OpenAI API key in Settings",
                    Toast.LENGTH_LONG
                ).show()
            }, 1500)
        }
    }

    // ==========================================
    // BACK PRESS HANDLING
    // ==========================================

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!navController.navigateUp()) {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    // ==========================================
    // PUBLIC HELPERS
    // ==========================================

    fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    fun getNavController() = navController
}