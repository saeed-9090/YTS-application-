package com.shortsai.app.video

import com.shortsai.app.api.models.VideoScript

/**
 * Holds all metadata about generated video
 * Used for display in PreviewFragment
 */
data class VideoMetadata(

    // Basic info
    val title: String,
    val topic: String,
    val videoPath: String,

    // Script data
    val script: VideoScript,

    // Technical info
    val durationSecs: Long = 0,
    val fileSizeMB: Double = 0.0,
    val sceneCount: Int = 0,
    val resolution: String = "1080x1920",

    // Generation info
    val generatedAt: Long = System.currentTimeMillis()
) {

    // ==========================================
    // DISPLAY HELPERS
    // ==========================================

    fun getDurationFormatted(): String {
        return when {
            durationSecs < 60 -> "${durationSecs}s"
            else -> "${durationSecs / 60}m ${durationSecs % 60}s"
        }
    }

    fun getFileSizeFormatted(): String {
        return String.format("%.1f MB", fileSizeMB)
    }

    fun getHashtagsFormatted(): String {
        return script.hashtags.joinToString(" ")
    }

    fun getSceneCountText(): String {
        return "$sceneCount scenes"
    }

    fun isValid(): Boolean {
        return videoPath.isNotEmpty() && title.isNotEmpty()
    }
}