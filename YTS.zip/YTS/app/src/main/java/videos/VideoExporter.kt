package com.shortsai.app.video

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.shortsai.app.utils.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class VideoExporter(private val context: Context) {

    private val TAG = "VideoExporter"

    // ==========================================
    // SHARE VIDEO
    // ==========================================

    /**
     * Share video via Android share sheet
     */
    fun shareVideo(videoPath: String) {
        try {
            val videoFile = File(videoPath)

            if (!FileUtils.isValidFile(videoFile)) {
                Log.e(TAG, "Video file not found for sharing")
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                videoFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(
                    Intent.EXTRA_TEXT,
                    "🎬 Created with AI Shorts Generator!"
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(
                shareIntent,
                "Share your Short"
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(chooser)
            Log.d(TAG, "Share intent launched")

        } catch (e: Exception) {
            Log.e(TAG, "Share failed: ${e.message}")
        }
    }

    // ==========================================
    // SAVE TO GALLERY
    // ==========================================

    /**
     * Save video to gallery and return URI
     */
    suspend fun saveToGallery(videoPath: String): Uri? {
        return withContext(Dispatchers.IO) {
            try {
                val videoFile = File(videoPath)

                if (!FileUtils.isValidFile(videoFile)) {
                    Log.e(TAG, "Video file invalid")
                    return@withContext null
                }

                val uri = FileUtils.saveVideoToGallery(context, videoFile)
                Log.d(TAG, "Saved to gallery: $uri")
                uri

            } catch (e: Exception) {
                Log.e(TAG, "Gallery save failed: ${e.message}")
                null
            }
        }
    }

    // ==========================================
    // GET VIDEO INFO
    // ==========================================

    data class VideoInfo(
        val path: String,
        val sizeMB: Double,
        val durationSecs: Long,
        val exists: Boolean
    )

    suspend fun getVideoInfo(videoPath: String): VideoInfo {
        return withContext(Dispatchers.IO) {
            val file = File(videoPath)
            val exists = FileUtils.isValidFile(file)

            val duration = if (exists) {
                try {
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(videoPath)
                    val ms = retriever.extractMetadata(
                        android.media.MediaMetadataRetriever.METADATA_KEY_DURATION
                    )?.toLong() ?: 0L
                    retriever.release()
                    ms / 1000
                } catch (e: Exception) {
                    0L
                }
            } else {
                0L
            }

            VideoInfo(
                path = videoPath,
                sizeMB = if (exists) FileUtils.getFileSizeMB(file) else 0.0,
                durationSecs = duration,
                exists = exists
            )
        }
    }
}