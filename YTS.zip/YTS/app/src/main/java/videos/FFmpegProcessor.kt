package com.shortsai.app.video

import android.content.Context
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import com.shortsai.app.utils.Constants
import com.shortsai.app.utils.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

class FFmpegProcessor(private val context: Context) {

    private val TAG = "FFmpegProcessor"

    // ==========================================
    // INIT FFMPEG
    // ==========================================

    init {
        // Enable FFmpegKit logs
        FFmpegKitConfig.enableLogCallback { log ->
            Log.d(TAG, "FFmpeg: ${log.message}")
        }
        FFmpegKitConfig.enableStatisticsCallback { stats ->
            Log.v(TAG, "FFmpeg Stats: frame=${stats.videoFrameNumber}")
        }
        Log.d(TAG, "FFmpegProcessor initialized")
    }

    // ==========================================
    // EXECUTE FFMPEG COMMAND
    // ==========================================

    /**
     * Execute FFmpeg command asynchronously
     * Returns true if successful
     */
    suspend fun executeCommand(
        command: String,
        onProgress: ((Int) -> Unit)? = null,
        onStatistics: ((Statistics) -> Unit)? = null
    ): Boolean = suspendCancellableCoroutine { continuation ->

        Log.d(TAG, "Executing FFmpeg command:")
        Log.d(TAG, command)

        val session = FFmpegKit.executeAsync(
            command,
            { session ->
                // Completion callback
                val returnCode = session.returnCode

                when {
                    ReturnCode.isSuccess(returnCode) -> {
                        Log.d(TAG, "FFmpeg SUCCESS")
                        if (continuation.isActive) {
                            continuation.resume(true)
                        }
                    }
                    ReturnCode.isCancel(returnCode) -> {
                        Log.w(TAG, "FFmpeg CANCELLED")
                        if (continuation.isActive) {
                            continuation.resume(false)
                        }
                    }
                    else -> {
                        Log.e(TAG, "FFmpeg FAILED: ${session.failStackTrace}")
                        if (continuation.isActive) {
                            continuation.resume(false)
                        }
                    }
                }
            },
            { log ->
                // Log callback
                Log.v(TAG, "FFmpeg log: ${log.message}")
            },
            { statistics ->
                // Statistics callback
                onStatistics?.invoke(statistics)
                val frameNumber = statistics.videoFrameNumber
                if (frameNumber > 0) {
                    onProgress?.invoke(frameNumber)
                }
            }
        )

        // Cancel FFmpeg if coroutine is cancelled
        continuation.invokeOnCancellation {
            Log.d(TAG, "Cancelling FFmpeg session")
            FFmpegKit.cancel(session.sessionId)
        }
    }

    // ==========================================
    // IMAGE TO VIDEO (SLIDESHOW)
    // ==========================================

    /**
     * Convert list of images into a slideshow video
     * Each image displays for specified duration
     */
    suspend fun createSlideshow(
        imagePaths: List<String>,
        outputPath: String,
        durationPerImage: Int = Constants.VIDEO_DURATION_PER_SCENE,
        fps: Int = Constants.VIDEO_FPS,
        width: Int = Constants.VIDEO_WIDTH,
        height: Int = Constants.VIDEO_HEIGHT,
        onProgress: ((Int) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {

        Log.d(TAG, "Creating slideshow from ${imagePaths.size} images")

        // Write image list to concat file
        val concatFile = createConcatFile(imagePaths, durationPerImage)
            ?: return@withContext false

        // Build FFmpeg command for slideshow
        val command = buildString {
            append("-y ")                           // Overwrite output
            append("-f concat ")                    // Use concat demuxer
            append("-safe 0 ")                      // Allow absolute paths
            append("-i \"${concatFile.absolutePath}\" ")
            append("-vf \"")
            append("scale=${width}:${height}:")     // Scale to target size
            append("force_original_aspect_ratio=decrease,")
            append("pad=${width}:${height}:")       // Pad to exact size
            append("(ow-iw)/2:(oh-ih)/2,")
            append("setsar=1,")                     // Set sample aspect ratio
            append("fps=${fps}")                    // Set frame rate
            append("\" ")
            append("-c:v libx264 ")                 // H.264 codec
            append("-preset fast ")                 // Encoding speed
            append("-crf 23 ")                      // Quality (lower = better)
            append("-pix_fmt yuv420p ")             // Pixel format (compatibility)
            append("-movflags +faststart ")         // Web optimized
            append("\"${outputPath}\"")
        }

        val success = executeCommand(
            command = command,
            onProgress = onProgress
        )

        // Cleanup concat file
        concatFile.delete()

        if (success) {
            Log.d(TAG, "Slideshow created: $outputPath")
        } else {
            Log.e(TAG, "Slideshow creation failed")
        }

        success
    }

    // ==========================================
    // ADD AUDIO TO VIDEO
    // ==========================================

    /**
     * Merge audio track with video
     * Handles duration mismatch between audio and video
     */
    suspend fun addAudioToVideo(
        videoPath: String,
        audioPath: String,
        outputPath: String,
        onProgress: ((Int) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {

        Log.d(TAG, "Adding audio to video")
        Log.d(TAG, "Video: $videoPath")
        Log.d(TAG, "Audio: $audioPath")

        // Get audio duration first
        val audioDuration = getMediaDuration(audioPath)
        val videoDuration = getMediaDuration(videoPath)

        Log.d(TAG, "Audio duration: ${audioDuration}ms")
        Log.d(TAG, "Video duration: ${videoDuration}ms")

        val command = buildString {
            append("-y ")
            append("-i \"${videoPath}\" ")          // Input video
            append("-i \"${audioPath}\" ")          // Input audio
            append("-c:v copy ")                    // Copy video (no re-encode)
            append("-c:a aac ")                     // Audio codec
            append("-b:a 192k ")                    // Audio bitrate
            append("-map 0:v:0 ")                   // Map video stream
            append("-map 1:a:0 ")                   // Map audio stream

            // Handle duration: use shortest or loop video
            if (audioDuration > videoDuration) {
                // Audio longer than video - loop video
                append("-shortest ")
            } else {
                // Video longer than audio - trim to audio length
                append("-shortest ")
            }

            append("-movflags +faststart ")
            append("\"${outputPath}\"")
        }

        val success = executeCommand(
            command = command,
            onProgress = onProgress
        )

        if (success) {
            Log.d(TAG, "Audio merged successfully")
        } else {
            Log.e(TAG, "Audio merge failed")
        }

        success
    }

    // ==========================================
    // ADD SUBTITLES OVERLAY
    // ==========================================

    /**
     * Burn subtitles into video
     * Uses drawtext filter for each scene
     */
    suspend fun addSubtitlesOverlay(
        videoPath: String,
        outputPath: String,
        subtitles: List<SubtitleEntry>,
        onProgress: ((Int) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {

        Log.d(TAG, "Adding subtitles overlay (${subtitles.size} entries)")

        if (subtitles.isEmpty()) {
            // No subtitles - just copy file
            return@withContext copyFile(videoPath, outputPath)
        }

        // Build drawtext filter chain
        val drawtextFilters = subtitles.mapIndexed { index, subtitle ->
            buildDrawtextFilter(subtitle, index)
        }.joinToString(",")

        val command = buildString {
            append("-y ")
            append("-i \"${videoPath}\" ")
            append("-vf \"${drawtextFilters}\" ")
            append("-c:v libx264 ")
            append("-preset fast ")
            append("-crf 23 ")
            append("-c:a copy ")                    // Copy audio unchanged
            append("-pix_fmt yuv420p ")
            append("-movflags +faststart ")
            append("\"${outputPath}\"")
        }

        val success = executeCommand(
            command = command,
            onProgress = onProgress
        )

        if (success) {
            Log.d(TAG, "Subtitles added successfully")
        } else {
            Log.e(TAG, "Subtitle overlay failed")
        }

        success
    }

    // ==========================================
    // ADD BACKGROUND MUSIC (OPTIONAL)
    // ==========================================

    /**
     * Mix background music with voiceover
     * Music at lower volume (30%)
     */
    suspend fun mixAudioTracks(
        voiceoverPath: String,
        musicPath: String,
        outputPath: String,
        musicVolume: Float = 0.3f
    ): Boolean = withContext(Dispatchers.IO) {

        Log.d(TAG, "Mixing audio tracks")

        val command = buildString {
            append("-y ")
            append("-i \"${voiceoverPath}\" ")      // Main voiceover
            append("-i \"${musicPath}\" ")          // Background music
            append("-filter_complex \"")
            append("[0:a]volume=1.0[voice];")       // Voice at 100%
            append("[1:a]volume=${musicVolume}")     // Music at musicVolume%
            append("[music];")
            append("[voice][music]amix=inputs=2:")  // Mix both tracks
            append("duration=first:")               // Use voiceover duration
            append("dropout_transition=2")          // Smooth transition
            append("[mixed]\" ")
            append("-map 0:v? ")                    // Map video if exists
            append("-map \"[mixed]\" ")             // Map mixed audio
            append("-c:a aac ")
            append("-b:a 192k ")
            append("-c:v copy ")
            append("\"${outputPath}\"")
        }

        executeCommand(command)
    }

    // ==========================================
    // ADD FADE IN/OUT EFFECTS
    // ==========================================

    /**
     * Add fade in at start and fade out at end
     */
    suspend fun addFadeEffects(
        videoPath: String,
        outputPath: String,
        totalDurationSecs: Int,
        fadeInDuration: Float = 0.5f,
        fadeOutDuration: Float = 0.5f
    ): Boolean = withContext(Dispatchers.IO) {

        Log.d(TAG, "Adding fade effects")

        val fadeOutStart = totalDurationSecs - fadeOutDuration

        val command = buildString {
            append("-y ")
            append("-i \"${videoPath}\" ")
            append("-vf \"")
            // Fade in at start
            append("fade=t=in:st=0:d=${fadeInDuration},")
            // Fade out near end
            append("fade=t=out:st=${fadeOutStart}:d=${fadeOutDuration}")
            append("\" ")
            append("-af \"")
            // Audio fade in
            append("afade=t=in:st=0:d=${fadeInDuration},")
            // Audio fade out
            append("afade=t=out:st=${fadeOutStart}:d=${fadeOutDuration}")
            append("\" ")
            append("-c:v libx264 ")
            append("-preset fast ")
            append("-crf 23 ")
            append("-c:a aac ")
            append("-pix_fmt yuv420p ")
            append("-movflags +faststart ")
            append("\"${outputPath}\"")
        }

        val success = executeCommand(command)

        if (success) {
            Log.d(TAG, "Fade effects added")
        }

        success
    }

    // ==========================================
    // KENBURNS ZOOM EFFECT
    // ==========================================

    /**
     * Add Ken Burns (slow zoom) effect to images
     * Makes static images look more dynamic
     */
    suspend fun createSlideshowWithKenBurns(
        imagePaths: List<String>,
        outputPath: String,
        durationPerImage: Int = Constants.VIDEO_DURATION_PER_SCENE,
        fps: Int = Constants.VIDEO_FPS,
        width: Int = Constants.VIDEO_WIDTH,
        height: Int = Constants.VIDEO_HEIGHT,
        onProgress: ((Int) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {

        Log.d(TAG, "Creating Ken Burns slideshow")

        val totalFramesPerImage = durationPerImage * fps

        // Build complex filter for Ken Burns effect
        val filterParts = imagePaths.mapIndexed { index, imagePath ->
            buildString {
                append("[${index}:v]")
                append("scale=8000:-1,")            // Scale up for zoom
                // Zoom from 1.0 to 1.2 over duration
                append("zoompan=")
                append("z='min(zoom+0.0015,1.5)':")
                append("x='iw/2-(iw/zoom/2)':")
                append("y='ih/2-(ih/zoom/2)':")
                append("d=${totalFramesPerImage}:")
                append("s=${width}x${height}:")
                append("fps=${fps}")
                append(",setpts=PTS-STARTPTS")
                append("[v${index}]")
            }
        }

        // Concat all processed images
        val concatInputs = imagePaths.indices.joinToString("") { "[v$it]" }
        val filterComplex = filterParts.joinToString(";") +
                ";${concatInputs}concat=n=${imagePaths.size}:v=1:a=0[out]"

        // Build input args
        val inputArgs = imagePaths.joinToString(" ") { path ->
            "-loop 1 -t $durationPerImage -i \"$path\""
        }

        val command = buildString {
            append("-y ")
            append("$inputArgs ")
            append("-filter_complex \"$filterComplex\" ")
            append("-map \"[out]\" ")
            append("-c:v libx264 ")
            append("-preset fast ")
            append("-crf 23 ")
            append("-pix_fmt yuv420p ")
            append("-movflags +faststart ")
            append("\"${outputPath}\"")
        }

        val success = executeCommand(
            command = command,
            onProgress = onProgress
        )

        if (success) {
            Log.d(TAG, "Ken Burns slideshow created")
        }

        success
    }

    // ==========================================
    // TRIM VIDEO
    // ==========================================

    /**
     * Trim video to specified duration
     */
    suspend fun trimVideo(
        inputPath: String,
        outputPath: String,
        startSecs: Float = 0f,
        durationSecs: Float
    ): Boolean = withContext(Dispatchers.IO) {

        val command = buildString {
            append("-y ")
            append("-ss $startSecs ")               // Start time
            append("-i \"${inputPath}\" ")
            append("-t $durationSecs ")             // Duration
            append("-c:v libx264 ")
            append("-c:a aac ")
            append("-preset fast ")
            append("-crf 23 ")
            append("-pix_fmt yuv420p ")
            append("\"${outputPath}\"")
        }

        executeCommand(command)
    }

    // ==========================================
    // GET MEDIA DURATION
    // ==========================================

    /**
     * Get duration of media file in milliseconds
     */
    suspend fun getMediaDuration(
        mediaPath: String
    ): Long = withContext(Dispatchers.IO) {
        try {
            val retriever = android.media.MediaMetadataRetriever()
            retriever.setDataSource(mediaPath)
            val duration = retriever
                .extractMetadata(
                    android.media.MediaMetadataRetriever.METADATA_KEY_DURATION
                )?.toLong() ?: 0L
            retriever.release()
            duration
        } catch (e: Exception) {
            Log.e(TAG, "Duration check failed: ${e.message}")
            30000L
        }
    }

    // ==========================================
    // VALIDATE VIDEO FILE
    // ==========================================

    /**
     * Validate that output video is playable
     */
    suspend fun validateVideo(videoPath: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(videoPath)
                if (!file.exists() || file.length() == 0L) {
                    Log.e(TAG, "Video file empty or missing")
                    return@withContext false
                }

                val duration = getMediaDuration(videoPath)
                if (duration <= 0) {
                    Log.e(TAG, "Video has no duration")
                    return@withContext false
                }

                Log.d(TAG, "Video valid: ${duration}ms, " +
                        "${FileUtils.getFileSizeMB(file)}MB")
                true

            } catch (e: Exception) {
                Log.e(TAG, "Validation failed: ${e.message}")
                false
            }
        }
    }

    // ==========================================
    // HELPER: CREATE CONCAT FILE
    // ==========================================

    /**
     * Create FFmpeg concat demuxer file
     * Format:
     * file '/path/to/image.jpg'
     * duration 5
     */
    private fun createConcatFile(
        imagePaths: List<String>,
        durationPerImage: Int
    ): File? {
        return try {
            val concatFile = File(
                FileUtils.getTempDir(context),
                "concat_list.txt"
            )

            val content = buildString {
                imagePaths.forEach { path ->
                    appendLine("file '${path}'")
                    appendLine("duration ${durationPerImage}")
                }
                // Add last image again (FFmpeg requirement)
                if (imagePaths.isNotEmpty()) {
                    appendLine("file '${imagePaths.last()}'")
                }
            }

            concatFile.writeText(content)
            Log.d(TAG, "Concat file created:\n$content")
            concatFile

        } catch (e: Exception) {
            Log.e(TAG, "Concat file creation failed: ${e.message}")
            null
        }
    }

    // ==========================================
    // HELPER: BUILD DRAWTEXT FILTER
    // ==========================================

    /**
     * Build FFmpeg drawtext filter for subtitles
     */
    private fun buildDrawtextFilter(
        subtitle: SubtitleEntry,
        index: Int
    ): String {
        // Escape special characters in text
        val escapedText = subtitle.text
            .replace("'", "\\'")
            .replace(":", "\\:")
            .replace(",", "\\,")

        return buildString {
            append("drawtext=")
            append("text='${escapedText}':")
            // Font settings
            append("fontsize=52:")
            append("fontcolor=white:")
            append("font='sans-serif':")
            // Shadow for readability
            append("shadowcolor=black@0.8:")
            append("shadowx=3:shadowy=3:")
            // Position: bottom center
            append("x=(w-text_w)/2:")
            append("y=h-text_h-120:")
            // Box background
            append("box=1:")
            append("boxcolor=black@0.6:")
            append("boxborderw=12:")
            // Timing
            append("enable='between(t,${subtitle.startSecs},${subtitle.endSecs})'")
        }
    }
   // ==========================================
    // HELPER: COPY FILE
    // ==========================================

    private suspend fun copyFile(
        sourcePath: String,
        destPath: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            File(sourcePath).copyTo(File(destPath), overwrite = true)
            true
        } catch (e: Exception) {
            Log.e(TAG, "File copy failed: ${e.message}")
            false
        }
    }
}

// ==========================================
// SUBTITLE ENTRY DATA CLASS
// ==========================================

data class SubtitleEntry(
    val text: String,
    val startSecs: Float,
    val endSecs: Float
)