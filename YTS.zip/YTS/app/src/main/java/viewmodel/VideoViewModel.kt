package com.shortsai.app.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shortsai.app.api.models.*
import com.shortsai.app.repository.ValidationResult
import com.shortsai.app.repository.VideoRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.catch

class VideoViewModel(
    private val repository: VideoRepository
) : ViewModel() {

    private val TAG = "VideoViewModel"

    // ==========================================
    // LIVE DATA - UI STATE
    // ==========================================

    // Generation state (Loading/Success/Error)
    private val _generationState = MutableLiveData<GenerationState>(
        GenerationState.Idle
    )
    val generationState: LiveData<GenerationState> = _generationState

    // Progress (0-100)
    private val _progress = MutableLiveData<Int>(0)
    val progress: LiveData<Int> = _progress

    // Progress message
    private val _progressMessage = MutableLiveData<String>("")
    val progressMessage: LiveData<String> = _progressMessage

    // Final video path
    private val _videoPath = MutableLiveData<String>("")
    val videoPath: LiveData<String> = _videoPath

    // Generated script
    private val _videoScript = MutableLiveData<VideoScript?>()
    val videoScript: LiveData<VideoScript?> = _videoScript

    // Toast messages
    private val _toastMessage = MutableLiveData<String>()
    val toastMessage: LiveData<String> = _toastMessage

    // Gallery save state
    private val _gallerySaveState = MutableLiveData<GallerySaveState>()
    val gallerySaveState: LiveData<GallerySaveState> = _gallerySaveState

    // API Key state
    private val _apiKeyState = MutableLiveData<ApiKeyState>()
    val apiKeyState: LiveData<ApiKeyState> = _apiKeyState

    // Is generating flag
    private val _isGenerating = MutableLiveData<Boolean>(false)
    val isGenerating: LiveData<Boolean> = _isGenerating

    // ==========================================
    // JOBS
    // ==========================================

    private var generationJob: Job? = null

    // ==========================================
    // MAIN: START VIDEO GENERATION
    // ==========================================

    fun generateVideo(topic: String) {

        // Validate input
        when (val validation = repository.validateTopic(topic)) {
            is ValidationResult.Error -> {
                _toastMessage.value = validation.message
                return
            }
            is ValidationResult.Success -> { /* proceed */ }
        }

        // Cancel any existing job
        cancelGeneration()

        // Start new generation
        generationJob = viewModelScope.launch {

            Log.d(TAG, "Starting video generation: $topic")
            _isGenerating.value = true
            _generationState.value = GenerationState.Loading(
                progress = 0,
                message = "🚀 Initializing..."
            )

            repository.generateCompleteVideo(topic)
                .catch { exception ->
                    Log.e(TAG, "Flow error: ${exception.message}")
                    _generationState.value = GenerationState.Error(
                        message = exception.localizedMessage
                            ?: "Unknown error occurred",
                        throwable = exception
                    )
                    _isGenerating.value = false
                }
                .collect { state ->
                    handleGenerationState(state)
                }
        }
    }

    // ==========================================
    // STATE HANDLER
    // ==========================================

    private fun handleGenerationState(state: GenerationState) {
        Log.d(TAG, "State: $state")

        when (state) {
            is GenerationState.Idle -> {
                _isGenerating.value = false
                _generationState.value = state
            }

            is GenerationState.Loading -> {
                _progress.value = state.progress
                _progressMessage.value = state.message
                _generationState.value = state

                Log.d(TAG, "Progress: ${state.progress}% - ${state.message}")
            }

            is GenerationState.Success -> {
                Log.d(TAG, "Generation SUCCESS!")
                Log.d(TAG, "Video: ${state.videoPath}")

                _progress.value = Constants.Progress.STEP_COMPLETE
                _progressMessage.value = Constants.Progress.MSG_COMPLETE
                _videoPath.value = state.videoPath
                _videoScript.value = state.videoScript
                _isGenerating.value = false
                _generationState.value = state
            }

            is GenerationState.Error -> {
                Log.e(TAG, "Generation ERROR: ${state.message}")

                _isGenerating.value = false
                _generationState.value = state
                _toastMessage.value = state.message
            }
        }
    }

    // ==========================================
    // CANCEL GENERATION
    // ==========================================

    fun cancelGeneration() {
        generationJob?.cancel()
        generationJob = null
        _isGenerating.value = false
        _generationState.value = GenerationState.Idle
        _progress.value = 0
        _progressMessage.value = ""
        Log.d(TAG, "Generation cancelled")
    }

    // ==========================================
    // SAVE TO GALLERY
    // ==========================================

    fun saveVideoToGallery() {
        val path = _videoPath.value

        if (path.isNullOrEmpty()) {
            _toastMessage.value = "No video to save"
            return
        }

        viewModelScope.launch {
            _gallerySaveState.value = GallerySaveState.Saving

            val result = repository.saveVideoToGallery(path)

            result.fold(
                onSuccess = { message ->
                    Log.d(TAG, "Video saved to gallery")
                    _gallerySaveState.value = GallerySaveState.Success(message)
                    _toastMessage.value = "✅ Video saved to Gallery!"
                },
                onFailure = { exception ->
                    Log.e(TAG, "Gallery save failed: ${exception.message}")
                    _gallerySaveState.value = GallerySaveState.Error(
                        exception.localizedMessage ?: "Save failed"
                    )
                    _toastMessage.value = "❌ Failed to save video"
                }
            )
        }
    }

    // ==========================================
    // API KEY MANAGEMENT
    // ==========================================

    fun saveApiKey(apiKey: String) {
        if (apiKey.isBlank()) {
            _apiKeyState.value = ApiKeyState.Error("API key cannot be empty")
            return
        }

        if (!apiKey.startsWith("sk-")) {
            _apiKeyState.value = ApiKeyState.Error(
                "Invalid API key format. Should start with 'sk-'"
            )
            return
        }

        repository.saveApiKey(apiKey)
        _apiKeyState.value = ApiKeyState.Saved
        _toastMessage.value = "✅ API key saved successfully!"
        Log.d(TAG, "API key saved")
    }

    fun getApiKey(): String = repository.getApiKey()

    fun hasValidApiKey(): Boolean = repository.hasValidApiKey()

    // ==========================================
    // STATS
    // ==========================================

    fun getVideoCount(): Int = repository.getVideoCount()

    fun getLastTopic(): String = repository.getLastTopic()

    // ==========================================
    // RESET STATE
    // ==========================================

    fun resetState() {
        _generationState.value = GenerationState.Idle
        _progress.value = 0
        _progressMessage.value = ""
        _videoPath.value = ""
        _videoScript.value = null
        _isGenerating.value = false
        Log.d(TAG, "State reset")
    }

    // ==========================================
    // CLEANUP
    // ==========================================

    fun cleanupTempFiles() {
        viewModelScope.launch {
            repository.cleanupTempFiles()
        }
    }

    override fun onCleared() {
        super.onCleared()
        generationJob?.cancel()
        Log.d(TAG, "ViewModel cleared")
    }

    // ==========================================
    // HELPER: PROGRESS TEXT
    // ==========================================

    fun getProgressText(): String {
        return when (val state = _generationState.value) {
            is GenerationState.Loading -> state.message
            is GenerationState.Success -> Constants.Progress.MSG_COMPLETE
            is GenerationState.Error -> "❌ ${state.message}"
            else -> ""
        }
    }

    // ==========================================
    // HELPER: SCRIPT INFO
    // ==========================================

    fun getScriptTitle(): String {
        return _videoScript.value?.title ?: ""
    }

    fun getScriptHashtags(): String {
        return _videoScript.value?.hashtags
            ?.joinToString(" ") ?: ""
    }

    fun getSceneCount(): Int {
        return _videoScript.value?.scenes?.size ?: 0
    }
}

// ==========================================
// ADDITIONAL STATE CLASSES
// ==========================================

sealed class GallerySaveState {
    object Saving : GallerySaveState()
    data class Success(val message: String) : GallerySaveState()
    data class Error(val message: String) : GallerySaveState()
}

sealed class ApiKeyState {
    object Saved : ApiKeyState()
    data class Error(val message: String) : ApiKeyState()
}

// Constant reference for ViewModel
private val Constants = com.shortsai.app.utils.Constants