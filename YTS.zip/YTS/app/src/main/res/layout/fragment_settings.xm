<?xml version="1.0" encoding="utf-8"?>
<androidx.core.widget.NestedScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/background"
    android:fillViewport="true">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="20dp">

        <!-- Title -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="⚙️ Settings"
            android:textColor="@color/text_primary"
            android:textSize="22sp"
            android:textStyle="bold"
            android:layout_marginBottom="24dp"/>

        <!-- API Key Card -->
        <androidx.cardview.widget.CardView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginBottom="16dp"
            app:cardBackgroundColor="@color/card_bg"
            app:cardCornerRadius="16dp"
            app:cardElevation="6dp">

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:padding="20dp">

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical"
                    android:layout_marginBottom="6dp">

                    <TextView
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:text="🔑 OpenAI API Key"
                        android:textColor="@color/text_primary"
                        android:textSize="15sp"
                        android:textStyle="bold"/>

                    <TextView
                        android:id="@+id/tv_api_status"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="Not Set"
                        android:textColor="@color/error"
                        android:textSize="12sp"
                        android:background="@drawable/badge_bg"
                        android:paddingHorizontal="8dp"
                        android:paddingVertical="4dp"/>

                </LinearLayout>

                <TextView
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:text="Get your key from platform.openai.com/api-keys"
                    android:textColor="@color/text_secondary"
                    android:textSize="12sp"
                    android:layout_marginBottom="16dp"/>

                <!-- API Key Input -->
                <com.google.android.material.textfield.TextInputLayout
                    android:id="@+id/til_api_key"
                    style="@style/DarkInputLayout"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:hint="sk-..."
                    app:endIconMode="password_toggle"
                    app:endIconTint="@color/text_secondary">

                    <com.google.android.material.textfield.TextInputEditText
                        android:id="@+id/et_api_key"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:textColor="@color/text_primary"
                        android:inputType="textPassword"
                        android:maxLines="1"/>

                </com.google.android.material.textfield.TextInputLayout>

                <!-- Save Key Button -->
                <Button
                    android:id="@+id/btn_save_key"
                    android:layout_width="match_parent"
                    android:layout_height="48dp"
                    android:text="Save API Key"
                    android:textColor="@color/text_primary"
                    android:background="@drawable/gradient_button"
                    android:stateListAnimator="@null"
                    android:layout_marginTop="14dp"/>

            </LinearLayout>

        </androidx.cardview.widget.CardView>

        <!-- Info Card -->
        <androidx.cardview.widget.CardView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginBottom="16dp"
            app:cardBackgroundColor="@color/card_bg"
            app:cardCornerRadius="16dp">

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:padding="20dp">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="📊 Usage Stats"
                    android:textColor="@color/text_primary"
                    android:textSize="15sp"
                    android:textStyle="bold"
                    android:layout_marginBottom="12dp"/>

                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center_vertical">

                    <TextView
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_weight="1"
                        android:text="Videos Generated"
                        android:textColor="@color/text_secondary"
                        android:textSize="13sp"/>

                    <TextView
                        android:id="@+id/tv_total_videos"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="0"
                        android:textColor="@color/primary"
                        android:textSize="16sp"
                        android:textStyle="bold"/>

                </LinearLayout>

            </LinearLayout>

        </androidx.cardview.widget.CardView>

        <!-- Clear Data Button -->
        <Button
            android:id="@+id/btn_clear_data"
            android:layout_width="match_parent"
            android:layout_height="48dp"
            android:text="🗑️ Clear All Data"
            android:textColor="@color/error"
            android:backgroundTint="@color/card_bg"
            style="@style/Widget.MaterialComponents.Button"/>

    </LinearLayout>

</androidx.core.widget.NestedScrollView>